1. Install python 3.5 and above

2. Run the command python sample.py

